<?php
	$host="localhost";
	$user="root";
	$password="";
	$dbname="e-surat";
	$cn=mysql_connect($host,$user,$password)or die(mysql_error());  
	$db=mysql_select_db($dbname,$cn)or die(mysql_error()); 
	
	if(isset($_GET['id']))
	{	
		$id=$_GET['id'];
		$sql_sel="select * from user where u_id=".$id;
		$result=mysql_query($sql_sel);
		
		while($tmp2=mysql_fetch_assoc($result)) 
	{
		?>
        <table>
		<tr>
			<td><?php $u_id=$tmp2['u_id']; ?></td>
			<td><?php $u_name=$tmp2['u_name']; ?></td>
			<td><?php $user_name=$tmp2['user_name']; ?></td>
			<td><?php $password=$tmp2['password']; ?></td>
			<td><?php $email_id=$tmp2['email_id']; ?></td>
            <td><?php $d_o_b=$tmp2['d_o_b']; ?></td>
            <td><?php $age=$tmp2['age']; ?></td>
            <td><?php $gender=$tmp2['gender']; ?></td>
            <td><?php $member_of_organization=$tmp2['member_of_organization']; ?></td>
            <td><?php $user_address=$tmp2['user_address']; ?></td>
            <td><?php $area=$tmp2['area']; ?></td>
            <td><?php $pincode=$tmp2['pincode']; ?></td>
            <td><?php $contect_no=$tmp2['contect_no']; ?></td>
            <td><?php $area_of_interest=$tmp2['area_of_interest']; ?></td>
            <td><?php $cast=$tmp2['cast']; ?></td>
            <td><?php $edu=$tmp2['edu']; ?></td>
            <td><?php $occup=$tmp2['occup']; ?></td>
            <td><?php $merital_status=$tmp2['merital_status']; ?></td>
         </tr> 
         </table>  
	<?php }
	}
?>
	
<html>
	<head>
		
	</head>
	<body>
    <div id="bank_reg" class="box1" hidden="hidden" >
		
		<table class="table table-striped table-bordered table-hover datatable" style="position:relative;top:10px;">
			
			<tr>
				<th>Full Name</th>
				<td><?php echo $u_name; ?></td>
			</tr>
			<tr>
				<th>User name</th>
				<td><?php echo $user_name; ?></td>
			</tr>
            <tr>
				<th>Password</th>
				<td><?php echo $password; ?></td>
			</tr>
            <tr>
				<th>Email Id</th>
				<td><?php echo $email_id; ?></td>
			</tr>
            <tr>
				<th>Date Of Birth</th>
				<td><?php echo $d_o_b; ?></td>
			</tr>
            <tr>
				<th>Age</th>
				<td><?php echo $age; ?></td>
			</tr>
            <tr>
				<th>Gender</th>
				<td><?php echo $gender; ?></td>
			</tr>
            <tr>
				<th>Member Of Organization</th>
				<td><?php echo $member_of_organization; ?></td>
			</tr>
            <tr>
				<th>User Address</th>
				<td><?php echo $user_address; ?></td>
			</tr>
            <tr>
				<th>Area</th>
				<td><?php echo $area; ?></td>
			</tr>
            <tr>
				<th>Pincode</th>
				<td><?php echo $pincode; ?></td>
			</tr>
            <tr>
				<th>Contect Number</th>
				<td><?php echo $contect_no; ?></td>
			</tr>
            <tr>
				<th>Area Of Interest</th>
				<td><?php echo $area_of_interest; ?></td>
			</tr>
            <tr>
				<th>Cast</th>
				<td><?php echo $cast; ?></td>
			</tr>
            <tr>
				<th>Education</th>
				<td><?php echo $edu; ?></td>
			</tr>
            <tr>
				<th>Occupation</th>
				<td><?php echo $occup; ?></td>
			</tr>
            <tr>
				<th>Merital Status</th>
				<td><?php echo $merital_status; ?></td>
			</tr>
            	<label id="close" class="close" ><a href="#.php" style="{text-decoration:none;color:blue;}">Close</a></label>
		</table>
</div>		
	</body>
</html>