<?php
	$host="localhost";
	$user="root";
	$password="";
	$dbname="e-surat";
	$cn=mysql_connect($host,$user,$password)or die(mysql_error());  
	$db=mysql_select_db($dbname,$cn)or die(mysql_error()); 
	
	if(isset($_GET['id']))
	{	
		$id=$_GET['id'];
		$sql_sel="select * from event_mst where e_id=".$id;
		$result=mysql_query($sql_sel);
		
		while($tmp2=mysql_fetch_assoc($result)) 
	{
		?>
        <table>
		<tr>
			<td><?php $e_id=$tmp2['e_id']; ?></td>
			<td><?php $type=$tmp2['type']; ?></td>
			<td><?php $e_name=$tmp2['e_name']; ?></td>
			<td><?php $e_disc=$tmp2['e_disc']; ?></td>
			<td><?php $s_time=$tmp2['s_time']; ?></td>
            <td><?php $e_time=$tmp2['e_time']; ?></td>
            <td><?php $venue=$tmp2['venue']; ?></td>
            <td><?php $e_organizer=$tmp2['e_organizer']; ?></td>
            <td><?php $org_contact=$tmp2['org_contact']; ?></td>
            <td><?php $image=$tmp2['image']; ?></td>
         </tr> 
         </table>  
	<?php }
	}
?>
	
<html>
	<head>
		
	</head>
	<body>
		
        <div id="bank_reg" class="box1" hidden="hidden" >
        
		<table class="table table-striped table-bordered table-hover datatable" style="position:relative;top:10px;">
			
			<tr>
				<th>Type</th>
				<td><?php echo $type; ?></td>
			</tr>
			<tr>
				<th>Event Name</th>
				<td><?php echo $e_name; ?></td>
			</tr>
            <tr>
				<th>Event Discription</th>
				<td><?php echo $e_disc; ?></td>
			</tr>
            <tr>
				<th>Starting Time</th>
				<td><?php echo $s_time; ?></td>
			</tr>
            <tr>
				<th>Ending Time</th>
				<td><?php echo $e_time; ?></td>
			</tr>
            <tr>
				<th>Venue</th>
				<td><?php echo $venue; ?></td>
			</tr>
            <tr>
				<th>Organizer</th>
				<td><?php echo $e_organizer; ?></td>
			</tr>
            <tr>
				<th>Contact</th>
				<td><?php echo $org_contact; ?></td>
			</tr>
            <tr>
				<th></th>
				<td><?php echo "<img src='$image' height='20' width='20'>"; ?></td>
			</tr>
            	<label id="close" class="close" ><a href="#.php" style="{text-decoration:none;color:blue;}">Close</a></label>
		</table>
        
        </div>
	</body>
</html>