<?php
	$host="localhost";
	$user="root";
	$password="";
	$dbname="e-surat";
	$cn=mysql_connect($host,$user,$password)or die(mysql_error());  
	$db=mysql_select_db($dbname,$cn)or die(mysql_error()); 
	
	if(isset($_GET['id']))
	{	
		$id=$_GET['id'];
		$sql_sel="select * from organization where o_id=".$id;
		$result=mysql_query($sql_sel);
		
		while($tmp2=mysql_fetch_assoc($result)) 
	{
		?>
        <table>
		<tr>
			<td><?php $o_id=$tmp2['o_id']; ?></td>
			<td><?php $o_name=$tmp2['o_name']; ?></td>
			<td><?php $o_registration_no=$tmp2['o_registration_no']; ?></td>
			<td><?php $o_starting_year=$tmp2['o_starting_year']; ?></td>
			<td><?php $head_of_org=$tmp2['head_of_org']; ?></td>
            <td><?php $user_name=$tmp2['user_name']; ?></td>
            <td><?php $password=$tmp2['password']; ?></td>
            <td><?php $email_id=$tmp2['email_id']; ?></td>
            <td><?php $o_address=$tmp2['o_address']; ?></td>
            <td><?php $area=$tmp2['area']; ?></td>
            <td><?php $pincode=$tmp2['pincode']; ?></td>
            <td><?php $head_cont_no=$tmp2['head_cont_no']; ?></td>
            <td><?php $office_cont_no=$tmp2['office_cont_no']; ?></td>
            <td><?php $web_url=$tmp2['web_url']; ?></td>
            <td><?php $logo=$tmp2['logo']; ?></td>
         </tr> 
         </table>  
	<?php }
	}
?>
	
<html>
	<head>
		
	</head>
	<body>
    <div id="bank_reg" class="box1" hidden="hidden" >
		
		<table class="table table-striped table-bordered table-hover datatable" style="position:relative;top:10px;">
			
			<tr>
				<th>Organization Name</th>
				<td><?php echo $o_name; ?></td>
			</tr>
			<tr>
				<th>Registration Number</th>
				<td><?php echo $o_registration_no; ?></td>
			</tr>
            <tr>
				<th>Starting Year</th>
				<td><?php echo $o_starting_year; ?></td>
			</tr>
            <tr>
				<th>Head Of Organization</th>
				<td><?php echo $head_of_org; ?></td>
			</tr>
            <tr>
				<th>User Name</th>
				<td><?php echo $user_name; ?></td>
			</tr>
            <tr>
				<th>Password</th>
				<td><?php echo $password; ?></td>
			</tr>
            <tr>
				<th>Email Id</th>
				<td><?php echo $email_id; ?></td>
			</tr>
            <tr>
				<th>Organization Address</th>
				<td><?php echo $o_address; ?></td>
			</tr>
            <tr>
				<th>Area</th>
				<td><?php echo $area; ?></td>
			</tr>
            <tr>
				<th>Pincode</th>
				<td><?php echo $pincode; ?></td>
			</tr>
            <tr>
				<th>Head Contect Number</th>
				<td><?php echo $head_cont_no; ?></td>
			</tr>
            <tr>
				<th>Office Contect Number</th>
				<td><?php echo $office_cont_no; ?></td>
			</tr>
            <tr>
				<th>Website URL</th>
				<td><?php echo $web_url; ?></td>
			</tr>
            <tr>
				<th>Logo</th>
				<td><?php echo "<img src='$logo' height='20px' width='20px'>"; ?></td>
			</tr>
            	<label id="close" class="close" ><a href="#.php" style="{text-decoration:none;color:blue;}">Close</a></label>
			
		</table>
		</div>
	</body>
</html>