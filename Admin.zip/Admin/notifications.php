<?php

$con=mysql_connect("localhost","root","");
$sel_db=mysql_select_db("e-surat",$con);

$osel="select * from organization where verify=1 and valid=1";
$ores=mysql_query($osel,$con);
$org=mysql_num_rows($ores);

$usel="select * from user where verify=1 and valid=1";
$ures=mysql_query($usel,$con);
$user=mysql_num_rows($ures);

$esel="select * from event_mst where verify=1 and valid=1";
$eres=mysql_query($esel,$con);
$event=mysql_num_rows($eres);

$nsel="select * from news_mst where verify=1 and valid=1";
$nres=mysql_query($nsel,$con);
$news=mysql_num_rows($nres);

$ssel="select * from story_mst where verify=1 and valid=1";
$sres=mysql_query($ssel,$con);
$story=mysql_num_rows($sres);

/* notification total*/

$osel="select * from organization where verify=0 or valid=0";
$ores=mysql_query($osel,$con);
$org1=mysql_num_rows($ores);

$usel="select * from user where verify=0 or valid=0";
$ures=mysql_query($usel,$con);
$user1=mysql_num_rows($ures);

$esel="select * from event_mst where verify=0 or valid=0";
$eres=mysql_query($esel,$con);
$event1=mysql_num_rows($eres);

$nsel="select * from news_mst where verify=0 or valid=0";
$nres=mysql_query($nsel,$con);
$news1=mysql_num_rows($nres);

$ssel="select * from story_mst where verify=0 or valid=0";
$sres=mysql_query($ssel,$con);
$story1=mysql_num_rows($sres);
 
?>

<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  

  <link rel='stylesheet' href='f997549b24fbf810e2531be138edb2d5.css'>

  <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700|Open+Sans:400,700,300' rel='stylesheet' type='text/css'>

  <link href="assets/favicon.ico" rel="shortcut icon">
  <link href="assets/apple-touch-icon.png" rel="apple-touch-icon">
 
  <title>Admin of E-Surat</title>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-42863888-3', 'pinsupreme.com');
    ga('send', 'pageview');

</script>

</head>

<body>

<div class="all-wrapper">
  <div class="row">
    <div class="col-md-3">
      <div class="text-center">
  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </button>
</div>
<div class="side-bar-wrapper collapse navbar-collapse navbar-ex1-collapse">
  <a href="#" class="logo hidden-sm hidden-xs">
    <i class="icon-cloud-download"></i>
    <span>E-Surat</span>
  </a>
  <div class="search-box">
    <input type="text" placeholder="SEARCH" class="form-control">
  </div>
  <ul class="side-menu">
    <li>
      <a href="notifications.php" style="text-decoration:none;">
        <span class="badge badge-notifications pull-right alert-animated"><?php echo $org1+$user1+$event1+$news1+$story1; ?></span>
        <i class="icon-flag"></i> Notifications
      </a>
    </li>
  </ul>
  <div class="relative-w">
    <ul class="side-menu">
      <li>
        <a href="main.php" style="text-decoration:none;">
          <span class="badge pull-right"><?php echo $org+$user+$event+$news+$story; ?></span>
          <i class="icon-dashboard"></i> Dashboard
        </a>
      </li>
      <li class='current'>
        <a href="" class="is-dropdown-menu" style="text-decoration:none;">
          <span class="badge pull-right"><?php echo $org+$user+$event+$news+$story; ?></span>
          <i class="icon-th"></i> Tables
        </a>
        <ul>
          <li>
            <a href="o_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Organization
            </a>
          </li>
          <li>
            <a href="u_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              User
            </a>
          </li>
          <li>
            <a href="e_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Events
            </a>
          </li>
          <li>
            <a href="n_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              News
            </a>
          </li>
          <li>
            <a href="s_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Story
            </a>
          </li>
          <li>
            <a href="a_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Admin
            </a>
          </li>
        </ul>
      </li>
     <!-- <li>
        <a href="login.php" style="text-decoration:none;">
          <span class="badge pull-right"></span>
          <i class="icon-signin"></i> Login Page
        </a>
      </li>-->
    </ul>

  </div>
</div>
    </div>
    <div class="col-md-9">

      <div class="content-wrapper wood-wrapper">
        <div class="content-inner">
          <div class="page-header">
  <div class="header-links hidden-xs">
    <a href="login.php"><i class="icon-signout"></i> Logout</a>
  </div>
  <h1><i class="icon-bar-chart"></i> Notifications</h1>
</div>
<ol class="breadcrumb">
  <li><a href="main.php" style="text-decoration:none;">Home</a></li>
</ol>
          <div class="main-content">
            <div class="widget" id="tab">
              <div class="widget-controls pull-right">
                <a href="#" class="widget-link-remove"><i class="icon-minus-sign"></i></a>
                <a href="#" class="widget-link-remove"><i class="icon-remove-sign"></i></a>
              </div>
              <h3 class="section-title first-title"><i class="icon-tasks"></i> Notifications</h3>
              <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block"><a href="new_org.php" style="text-decoration:none;">New Organization</a></div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $org1; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center hidden-md" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block"><a href="new_user.php" style="text-decoration:none;">New Users</a></div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $user1; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block"><a href="new_event.php" style="text-decoration:none;">New Events</a></div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $event1; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:24%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block"><a href="new_news.php" style="text-decoration:none;">New News</a></div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $news1; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center hidden-md" style="position:relative; left:24%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block"><a href="new_story.php" style="text-decoration:none;">New Story</a></div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $story1; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


</body>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src='fb448e3c7d87cc9e5153600549474ccc.js'></script>

<script src='15a0b84663e72cbef64a7b3ee6cd86b8.js'></script>

</html>