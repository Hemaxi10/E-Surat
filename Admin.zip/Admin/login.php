<?php

ob_start();
session_start();

$con=mysql_connect("localhost","root","");
$sel_db=mysql_select_db("e-surat",$con);

if(isset($_POST['submit']))
{
	$uname=$_POST['uname'];
	$pass=$_POST['pass'];
		   
	if(empty($uname) && empty($pass))
	{  
		echo "<script>alert(\"Please Enter Username and Password\");</script>";
	}
	   
	else
	{  
		$query=mysql_query("select uname,password from admin_mst where uname='".mysql_real_escape_string($uname)."' AND password='".mysql_real_escape_string($pass)."'");
        while($rs=mysql_fetch_object($query))
		{  
			$uname=$rs->uname;
            $pass=$rs->password;
    	}
			
		if(mysql_num_rows($query)==0)
		{
			echo "<script>alert(\"Wrong Username or Password\");</script>";
		}
		else if(mysql_num_rows($query)==1)
		{
			$_SESSION['uname']=$uname;
			header('location:main.php');	
		}   
	}
}

?>

<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  

  <link rel='stylesheet' href='f997549b24fbf810e2531be138edb2d5.css'>

  <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700|Open+Sans:400,700,300' rel='stylesheet' type='text/css'>

  <link href="assets/favicon.ico" rel="shortcut icon">
  <link href="assets/apple-touch-icon.png" rel="apple-touch-icon">

  <title>Admin of E-Surat</title>

</head>

<body>

  <script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-42863888-3', 'pinsupreme.com');
    ga('send', 'pageview');

  </script>

<div class="all-wrapper no-menu-wrapper">
  <div class="login-logo-w">
    <a href="" class="logo">
      <i class="icon-cloud-download"></i>
      <span>E-Surat Admin</span>
    </a>
  </div>
  <div class="row">
    <div class="col-md-4 col-md-offset-4">

      <div class="content-wrapper bold-shadow">
        <div class="content-inner">
          <div class="main-content main-content-grey-gradient no-page-header">
            <div class="main-content-inner">
            <form action="#" role="form" method="post">
              <h3 class="form-title form-title-first"><i class="icon-lock"></i> Login Example</h3>
              <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" placeholder="Enter uname" name="uname">
              </div>
              <div class="form-group">
                <label>Password</label>
                <input type="password" class="form-control" placeholder="Password" name="pass">
              </div>
              <div class="form-group">
                <div class="checkbox">
                  <label>
                    <input type="checkbox"> Remember me
                  </label>
                </div>
              </div>
              <input type="submit" name="submit" value="Sign in" class="btn btn-primary btn-lg">
              <!--<input type="submit" name="cancel" value="Cancel" class="btn btn-link">-->
			  <a href="" class="forgot-pwd">Forgot Password?</a>
            </form>
            </div>
			<!--  start forgotbox ................................................................................... -->
<!--	<div id="forgotbox">
		<div id="forgotbox-text">Please send us your email and we'll reset your password.</div>
		<!--  start forgot-inner -->
		<!--<div id="forgot-inner">
		<table border="0" cellpadding="0" cellspacing="0">
		<tr>
			<th>Email address:</th>
			<td><input type="text" value=""   class="login-inp" /></td>
		</tr>
		<tr>
			<th> </th>
			<td><input type="button" class="submit-login"  /></td>
		</tr>
		</table>
		</div>
		<!--  end forgot-inner -->
		<!--<div class="clear"></div>
		<a href="" class="back-login">Back to login</a>
	</div>-->
	<!--  end forgotbox -->

          </div>
        </div>
      </div>
    </div>
  </div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src='fb448e3c7d87cc9e5153600549474ccc.js'></script>

</body>

</html>