<?php

	$host="localhost";
	$user="root";
	$password="";
	$dbname="e-surat";
	$cn=mysql_connect($host,$user,$password)or die(mysql_error());  
	$db=mysql_select_db($dbname,$cn)or die(mysql_error()); 

$osel="select * from organization where verify=1 and valid=1";
$ores=mysql_query($osel,$cn);
$org=mysql_num_rows($ores);

$usel="select * from user where verify=1 and valid=1";
$ures=mysql_query($usel,$cn);
$user=mysql_num_rows($ures);

$esel="select * from event_mst where verify=1 and valid=1";
$eres=mysql_query($esel,$cn);
$event=mysql_num_rows($eres);

$nsel="select * from news_mst where verify=1 and valid=1";
$nres=mysql_query($nsel,$cn);
$news=mysql_num_rows($nres);

$ssel="select * from story_mst where verify=1 and valid=1";
$sres=mysql_query($ssel,$cn);
$story=mysql_num_rows($sres);

/* notification total*/

$osel="select * from organization where verify=0 or valid=0";
$ores=mysql_query($osel,$cn);
$org1=mysql_num_rows($ores);

$usel="select * from user where verify=0 or valid=0";
$ures=mysql_query($usel,$cn);
$user1=mysql_num_rows($ures);

$esel="select * from event_mst where verify=0 or valid=0";
$eres=mysql_query($esel,$cn);
$event1=mysql_num_rows($eres);

$nsel="select * from news_mst where verify=0 or valid=0";
$nres=mysql_query($nsel,$cn);
$news1=mysql_num_rows($nres);

$ssel="select * from story_mst where verify=0 or valid=0";
$sres=mysql_query($ssel,$cn);
$story1=mysql_num_rows($sres);

if(isset($_GET['op']))
	{
		if($_GET['op']=="delete")
		{
			$sql_del="delete from user where u_id=".$_GET['id'];
			$qry_del=mysql_query($sql_del); 
			header("Location:u_table.php"); 
		}
	}
	$sql_sel="select * from user where valid=1 order by u_id";
	$qry_sel_people=mysql_query($sql_sel);
	
	if(isset($_GET['op']) && $_GET['op'] == "view")
		{
			echo str_repeat("<br>",2);
			include "user_view.php";	
		}
?>
	
<!DOCTYPE html>
<html>

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  

  <link rel='stylesheet' href='f997549b24fbf810e2531be138edb2d5.css'>

  <link href='http://fonts.googleapis.com/css?family=Oswald:300,400,700|Open+Sans:400,700,300' rel='stylesheet' type='text/css'>

  <link href="assets/favicon.ico" rel="shortcut icon">
  <link href="assets/apple-touch-icon.png" rel="apple-touch-icon">
<link rel="stylesheet" type="text/css" href="CSS/light.css" />

<script language="javascript" src="js/jquery.js"></script>
<script language="javascript">
		$(document).ready(function() {
			if($('#bank_reg').text()!="")
			{
				$('#main1').css("display","block");
				$('#bank_reg').css("display","block");
			}
			$('.close').click(function()
			{
				$('#main1').css("display","none");
				$('#bank_reg').css("display","none");

			})
		});
</script>

<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-42863888-3', 'pinsupreme.com');
    ga('send', 'pageview');

  </script>


  <title>Admin of E-Surat</title>

</head>
<body>

<!--           
            <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src='fb448e3c7d87cc9e5153600549474ccc.js'></script>

<script src='67b4d81b44effbc5e221a119f719782b.js'></script>

        
</body>

<body>
-->
<div class="all-wrapper">
  <div class="row">
    <div class="col-md-3">
      <div class="text-center">
  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
    <span class="sr-only">Toggle navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
  </button>
</div>
<div class="side-bar-wrapper collapse navbar-collapse navbar-ex1-collapse">
  <a href="#" class="logo hidden-sm hidden-xs">
    <i class="icon-cloud-download"></i>
    <span>E-Surat</span>
  </a>
  <div class="search-box">
    <input type="text" placeholder="SEARCH" class="form-control">
  </div>
  <ul class="side-menu">
    <li>
      <a href="notifications.php" style="text-decoration:none;">
        <span class="badge badge-notifications pull-right alert-animated"><?php echo $org1+$user1+$event1+$news1+$story1; ?></span>
        <i class="icon-flag"></i> Notifications
      </a>
    </li>
  </ul>
  <div class="relative-w">
    <ul class="side-menu">
      <li>
        <a href="main.php" style="text-decoration:none;">
          <span class="badge pull-right"><?php echo $org+$user+$event+$news+$story; ?></span>
          <i class="icon-dashboard"></i> Dashboard
        </a>
      </li>
      <li class='current'>
        <a href="" class="is-dropdown-menu" style="text-decoration:none;">
          <span class="badge pull-right"><?php echo $org+$user+$event+$news+$story; ?></span>
          <i class="icon-th"></i> Tables
        </a>
        <ul>
          <li>
            <a href="o_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Organization
            </a>
          </li>
          <li>
            <a href="u_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              User
            </a>
          </li>
          <li>
            <a href="e_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Events
            </a>
          </li>
          <li>
            <a href="n_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              News
            </a>
          </li>
          <li>
            <a href="s_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Story
            </a>
          </li>
          <li>
            <a href="a_table.php" style="text-decoration:none;">
              <i class="icon-table"></i>
              Admin
            </a>
          </li>
        </ul>
      </li>
      <!--<li>
        <a href="login.php" style="text-decoration:none;">
          <span class="badge pull-right"></span>
          <i class="icon-signin"></i> Login Page
        </a>
      </li>-->
    </ul>
  </div>
</div>
    </div>
    <div class="col-md-9">

      <div class="content-wrapper wood-wrapper">
        <div class="content-inner">
          <div class="page-header">
  <div class="header-links hidden-xs">
    <a href="login.php"><i class="icon-signout"></i> Logout</a>
  </div>
  <h1><i class="icon-bar-chart"></i> User Table</h1>
</div>
<ol class="breadcrumb">
  <li><a href="main.php" style="text-decoration:none;">Home</a></li>
</ol>
          <div class="main-content">
             <div class="widget">
            <div class="widget-controls pull-right">
                <a href="#" class="widget-link-remove"><i class="icon-minus-sign"></i></a>
                <a href="#" class="widget-link-remove"><i class="icon-remove-sign"></i></a>
              </div>
            <h3 class="section-title first-title"><i class="icon-table"></i> User Table</h3>
              <div class="widget-content-white glossed">
                <div class="padded">
                <table class="table table-striped table-bordered table-hover datatable">
                  <thead>
                    <tr>
                      <th><div class="checkbox"><input type="checkbox"></div></th>
                      <th>ID</th>
                      <th>User Name</th>
                      <th>Email-Id</th>
                      <th>Gender</th>
                      <th>Verify</th>
                      <th>Valid</th>
                      <th>Option</th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php
						while($tmp2=mysql_fetch_assoc($qry_sel_people)) 
						{
				  ?>
	
                    <tr>
                      <td><div class="checkbox"><input type="checkbox"></div></td>
                      <td><?php echo $tmp2['u_id']; ?></td>
                      <td><?php echo $tmp2['u_name']; ?></td>
                      <td><?php echo $tmp2['email_id']; ?></td>
                      <td><?php echo $tmp2['gender']; ?></td>
                      <td>
                      	<?php 
							$verify=$tmp2['verify'];
							$valid=$tmp2['valid'];
							
							if($verify==1)
							{
								echo "<img src='images/true.jpg' height='20' width='30'>";
							}
							else
							{
								echo "<img src='images/false.jpg' height='20' width='30'>";
							}
						?>
                      </td>
                      <td>
                      	<?php
						if($valid==1)
							{
								echo "<img src='images/true.jpg' height='20' width='30'>";
							}
							else
							{
								echo "<img src='images/false.jpg' height='20' width='30'>";
							}
                        ?>
                      </td>
                      <td class="text-right">
                        <a href="u_table.php?op=view&id=<?php echo $tmp2['u_id'];?>" class="btn btn-default btn-xs"></i> Select</a>
                        <a href="u_table.php?op=delete&id=<?php echo $tmp2['u_id'];?>" class="btn btn-danger btn-xs"><i class="icon-remove"></i></a>
                      </td>
                    </tr>
                    	<?php
							}
						?>
                  </tbody>
                </table>
                </div>
              </div>
            </div>
            <!--<div class="widget" id="tab">
              <div class="widget-controls pull-right">
                <a href="#" class="widget-link-remove"><i class="icon-minus-sign"></i></a>
                <a href="#" class="widget-link-remove"><i class="icon-remove-sign"></i></a>
              </div>
              <h3 class="section-title first-title"><i class="icon-tasks"></i> Dashboard</h3>
              <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total Visits</div>
                      <div class="value-block">
                        <div class="value-self">10,520</div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total Organization</div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $org; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center hidden-md" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total Users</div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $user; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total Events</div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $event; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total News</div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $news; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
                <div class="col-lg-3 col-md-4 col-sm-6 text-center hidden-md" style="position:relative; left:12%;">
                  <div class="widget-content-blue-wrapper changed-up">
                    <div class="widget-content-blue-inner padded">
                      <div class="pre-value-block">Total Story</div>
                      <div class="value-block">
                        <div class="value-self"><?php echo $story; ?></div>
                      </div>
                      <span class="dynamicsparkline">Loading..</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>-->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script src='fb448e3c7d87cc9e5153600549474ccc.js'></script>

<script src='15a0b84663e72cbef64a7b3ee6cd86b8.js'></script>

<div id="main1" class="main"></div>

</body>

</html>