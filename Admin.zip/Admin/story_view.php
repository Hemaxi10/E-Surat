<?php
	$host="localhost";
	$user="root";
	$password="";
	$dbname="e-surat";
	$cn=mysql_connect($host,$user,$password)or die(mysql_error());  
	$db=mysql_select_db($dbname,$cn)or die(mysql_error()); 
	
	if(isset($_GET['id']))
	{	
		$id=$_GET['id'];
		$sql_sel="select * from story_mst where s_id=".$id;
		$result=mysql_query($sql_sel);
		
		while($tmp2=mysql_fetch_assoc($result)) 
	{
		?>
        <table>
		<tr>
			<td><?php $s_id=$tmp2['s_id']; ?></td>
			<td><?php $type=$tmp2['type']; ?></td>
			<td><?php $s_name=$tmp2['s_name']; ?></td>
			<td><?php $s_detail=$tmp2['s_detail']; ?></td>
            <td><?php $image=$tmp2['image']; ?></td>
         </tr> 
         </table>  
	<?php }
	}
?>
	
<html>
	<head>
		
	</head>
	<body>
		
		<div id="bank_reg" class="box1" hidden="hidden" >
        
		<table class="table table-striped table-bordered table-hover datatable" style="position:relative;top:10px;">
			
			<tr>
				<th>Type</th>
				<td><?php echo $type; ?></td>
			</tr>
			<tr>
				<th>Story Name</th>
				<td><?php echo $s_name; ?></td>
			</tr>
            <tr>
				<th>Story Detail</th>
				<td><?php echo $s_detail; ?></td>
			</tr>
            <tr>
				<th></th>
				<td><?php echo "<img src='$image' height='20' width='20'>"; ?></td>
			</tr>
            	<label id="close" class="close" ><a href="#.php" style="{text-decoration:none;color:blue;}">Close</a></label>
		</table>
        </div>
	</body>
</html>